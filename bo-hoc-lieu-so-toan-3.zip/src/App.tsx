import React from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ToastContainer } from './components/Toast';
import { HomePage } from './pages/HomePage';
import { LibraryPage } from './pages/LibraryPage';
import { DetailPage } from './pages/DetailPage';
import { UploadPage } from './pages/UploadPage';
import { UserDashboard } from './pages/UserDashboard';
import { AdminDashboard } from './pages/AdminDashboard';
import { useResources } from './context/ResourceContext';

export const AppContent: React.FC = () => {
  const { activeTab } = useResources();

  return (
    <div className="min-h-screen bg-brand-bg flex flex-col font-sans text-brand-text">
      <Navbar />
      <ToastContainer />
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'home' && <HomePage />}
        {activeTab === 'library' && <LibraryPage />}
        {activeTab === 'detail' && <DetailPage />}
        {activeTab === 'upload' && <UploadPage />}
        {activeTab === 'dashboard' && <UserDashboard />}
        {activeTab === 'admin' && <AdminDashboard />}
      </main>
      <Footer />
    </div>
  );
};

export default AppContent;
