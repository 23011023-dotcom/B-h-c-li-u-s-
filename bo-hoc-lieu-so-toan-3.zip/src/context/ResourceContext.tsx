import React, { createContext, useContext, useState, useEffect } from 'react';
import { Resource, Category, FilterState, ToastMessage, ResourceType, CognitiveLevel, TeachingStage } from '../types';
import { INITIAL_CATEGORIES, INITIAL_RESOURCES } from '../data/initialData';

interface ResourceContextType {
  resources: Resource[];
  categories: Category[];
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  resetFilters: () => void;
  filteredResources: Resource[];
  favorites: string[];
  toggleFavorite: (id: string) => void;
  downloadResource: (id: string) => void;
  addResource: (newRes: Partial<Resource>) => void;
  approveResource: (id: string) => void;
  rejectResource: (id: string, reason: string) => void;
  toasts: ToastMessage[];
  showToast: (message: string, type?: ToastMessage['type']) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedResourceId: string | null;
  setSelectedResourceId: (id: string | null) => void;
}

const ResourceContext = createContext<ResourceContextType | undefined>(undefined);

const DEFAULT_FILTERS: FilterState = {
  keyword: '',
  types: [],
  categories: [],
  cognitiveLevels: [],
  teachingStages: [],
  sortBy: 'newest',
  page: 1,
};

export const ResourceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [resources, setResources] = useState<Resource[]>(() => {
    const saved = localStorage.getItem('toan3_resources');
    return saved ? JSON.parse(saved) : INITIAL_RESOURCES;
  });

  const [categories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);
  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('toan3_favorites');
    return saved ? JSON.parse(saved) : ['res-1', 'res-3'];
  });
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedResourceId, setSelectedResourceId] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('toan3_resources', JSON.stringify(resources));
  }, [resources]);

  useEffect(() => {
    localStorage.setItem('toan3_favorites', JSON.stringify(favorites));
  }, [favorites]);

  const showToast = (message: string, type: ToastMessage['type'] = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  const resetFilters = () => {
    setFilters(DEFAULT_FILTERS);
  };

  const toggleFavorite = (id: string) => {
    setFavorites(prev => {
      const exists = prev.includes(id);
      if (exists) {
        showToast('Đã xóa học liệu khỏi danh sách yêu thích.', 'info');
        return prev.filter(item => item !== id);
      } else {
        showToast('Đã thêm vào danh sách học liệu yêu thích!', 'success');
        return [...prev, id];
      }
    });
  };

  const downloadResource = (id: string) => {
    setResources(prev =>
      prev.map(r => (r.id === id ? { ...r, downloadCount: r.downloadCount + 1 } : r))
    );
    showToast('Bắt đầu tải xuống tệp học liệu... Vui lòng kiểm tra thư mục Download.', 'success');
  };

  const addResource = (newRes: Partial<Resource>) => {
    const created: Resource = {
      id: 'res-' + Date.now(),
      title: newRes.title || 'Học liệu mới',
      slug: (newRes.title || 'hoc-lieu').toLowerCase().replace(/\s+/g, '-'),
      description: newRes.description || '',
      type: newRes.type || 'worksheet',
      categoryId: newRes.categoryId || 'cat-1',
      categoryName: categories.find(c => c.id === newRes.categoryId)?.name || 'Chủ đề Toán 3',
      lessonName: newRes.lessonName || 'Bài học thực hành',
      cognitiveLevel: newRes.cognitiveLevel || 'nhan_biet',
      teachingStage: newRes.teachingStage || 'luyen_tap',
      thumbnailUrl: newRes.thumbnailUrl || 'https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=600&q=80',
      interactiveType: newRes.type === 'video' ? 'video' : newRes.type === 'game' ? 'canvas_game' : 'pdf',
      fileSize: newRes.fileSize || '2.5 MB',
      fileFormat: newRes.fileFormat || 'Tệp tài liệu',
      objective: newRes.objective || 'Mục tiêu học tập Toán 3',
      teachingGuide: newRes.teachingGuide || 'Hướng dẫn sử dụng',
      durationMinutes: newRes.durationMinutes || 15,
      authorId: newRes.authorId || 'usr-1',
      authorName: newRes.authorName || 'Giáo viên đóng góp',
      authorSchool: newRes.authorSchool || 'Tiểu học Việt Nam',
      copyrightInfo: newRes.copyrightInfo || 'Bản quyền giáo viên chia sẻ',
      status: 'pending', // Pending moderation
      ratingAverage: 5.0,
      ratingCount: 1,
      downloadCount: 0,
      viewCount: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      ...newRes,
    } as Resource;

    setResources(prev => [created, ...prev]);
    showToast('Đăng tải học liệu thành công! Tài liệu đang chờ Ban chuyên môn kiểm duyệt.', 'success');
  };

  const approveResource = (id: string) => {
    setResources(prev =>
      prev.map(r => (r.id === id ? { ...r, status: 'approved', rejectionReason: undefined } : r))
    );
    showToast('Đã phê duyệt học liệu thành công!', 'success');
  };

  const rejectResource = (id: string, reason: string) => {
    setResources(prev =>
      prev.map(r => (r.id === id ? { ...r, status: 'rejected', rejectionReason: reason } : r))
    );
    showToast('Đã từ chối học liệu kèm lý do phản hồi.', 'warning');
  };

  const filteredResources = resources.filter(res => {
    if (filters.keyword.trim()) {
      const q = filters.keyword.toLowerCase();
      const matchText = (res.title + ' ' + res.description + ' ' + res.categoryName + ' ' + (res.lessonName || '')).toLowerCase();
      if (!matchText.includes(q)) return false;
    }
    if (filters.types.length > 0 && !filters.types.includes(res.type)) return false;
    if (filters.categories.length > 0 && !filters.categories.includes(res.categoryId)) return false;
    if (filters.cognitiveLevels.length > 0 && !filters.cognitiveLevels.includes(res.cognitiveLevel)) return false;
    if (filters.teachingStages.length > 0 && !filters.teachingStages.includes(res.teachingStage)) return false;
    return true;
  }).sort((a, b) => {
    if (filters.sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    if (filters.sortBy === 'oldest') return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    if (filters.sortBy === 'rating') return b.ratingAverage - a.ratingAverage;
    if (filters.sortBy === 'downloads') return b.downloadCount - a.downloadCount;
    return 0;
  });

  return (
    <ResourceContext.Provider
      value={{
        resources,
        categories,
        filters,
        setFilters,
        resetFilters,
        filteredResources,
        favorites,
        toggleFavorite,
        downloadResource,
        addResource,
        approveResource,
        rejectResource,
        toasts,
        showToast,
        activeTab,
        setActiveTab,
        selectedResourceId,
        setSelectedResourceId,
      }}
    >
      {children}
    </ResourceContext.Provider>
  );
};

export const useResources = () => {
  const context = useContext(ResourceContext);
  if (!context) {
    throw new Error('useResources must be used within a ResourceProvider');
  }
  return context;
};
