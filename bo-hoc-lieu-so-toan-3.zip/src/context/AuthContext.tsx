import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  user: UserProfile | null;
  role: UserRole;
  login: (role: UserRole, email?: string) => void;
  logout: () => void;
  isAuthenticated: boolean;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEMO_USERS: Record<UserRole, UserProfile> = {
  teacher: {
    id: 'usr-1',
    email: 'nguyenthuha@tieuhoc.edu.vn',
    fullName: 'Cô Nguyễn Thu Hà',
    role: 'teacher',
    schoolName: 'Trường Tiểu học Lê Ngọc Hân, Hà Nội',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=120&q=80',
    created_at: '2026-09-01T08:00:00Z',
  },
  admin: {
    id: 'adm-1',
    email: 'admin.toan3@eduplatform.vn',
    fullName: 'Quản trị viên Ban Chuyên môn',
    role: 'admin',
    schoolName: 'Sở Giáo dục & Đào tạo / Ban Thư viện số',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80',
    created_at: '2026-08-15T08:00:00Z',
  },
  student: {
    id: 'stu-1',
    email: 'minhtri.lop3a@gmail.com',
    fullName: 'Nguyễn Minh Trí (Học sinh 3A)',
    role: 'student',
    schoolName: 'Tiểu học Lê Ngọc Hân',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
    created_at: '2026-09-10T08:00:00Z',
  }
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('toan3_user_session');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return DEMO_USERS.teacher;
      }
    }
    return DEMO_USERS.teacher; // Default logged in as Teacher for smooth demo
  });

  const login = (role: UserRole) => {
    const targetUser = DEMO_USERS[role];
    setUser(targetUser);
    localStorage.setItem('toan3_user_session', JSON.stringify(targetUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('toan3_user_session');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role: user?.role || 'student',
        login,
        logout,
        isAuthenticated: !!user,
        isAdmin: user?.role === 'admin',
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
