import React, { useState } from 'react';
import { 
  UploadCloud, 
  CheckCircle, 
  ArrowRight, 
  FileText, 
  Video, 
  Gamepad2, 
  MousePointerClick, 
  Info,
  ShieldAlert,
  Sparkles 
} from 'lucide-react';
import { useResources } from '../context/ResourceContext';
import { useAuth } from '../context/AuthContext';
import { ResourceType, CognitiveLevel, TeachingStage } from '../types';

export const UploadPage: React.FC = () => {
  const { categories, addResource, setActiveTab } = useResources();
  const { user } = useAuth();

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'worksheet' as ResourceType,
    categoryId: 'cat-3',
    lessonName: '',
    cognitiveLevel: 'thong_hieu' as CognitiveLevel,
    teachingStage: 'luyen_tap' as TeachingStage,
    objective: '',
    teachingGuide: '',
    durationMinutes: 15,
    fileSize: '3.2 MB',
    fileFormat: 'PDF Document',
    driveUrl: '',
    copyrightInfo: 'Giấy phép CC BY-NC 4.0 - Chia sẻ cho mục đích giáo dục phi thương mại.',
    confirmed: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.objective.trim()) {
      alert('Vui lòng điền đầy đủ các thông tin bắt buộc.');
      return;
    }
    if (!formData.confirmed) {
      alert('Vui lòng xác nhận bản quyền và kiểm duyệt nội dung trước khi gửi.');
      return;
    }

    addResource({
      title: formData.title,
      description: formData.description,
      type: formData.type,
      categoryId: formData.categoryId,
      lessonName: formData.lessonName || 'Toán lớp 3',
      cognitiveLevel: formData.cognitiveLevel,
      teachingStage: formData.teachingStage,
      objective: formData.objective,
      teachingGuide: formData.teachingGuide,
      durationMinutes: Number(formData.durationMinutes) || 15,
      authorName: user?.fullName || 'Cô Nguyễn Thu Hà',
      authorSchool: user?.schoolName || 'Tiểu học Việt Nam',
      copyrightInfo: formData.copyrightInfo,
      fileSize: formData.fileSize,
      fileFormat: formData.fileFormat,
      downloadUrl: formData.driveUrl || '#',
    });

    setActiveTab('dashboard');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12 text-left">
      
      {/* Title */}
      <div className="bg-white rounded-2xl border border-brand-border p-6 shadow-xs">
        <div className="flex items-center gap-2 text-xs font-bold text-brand-sky uppercase tracking-wider mb-1">
          <UploadCloud className="w-4 h-4 text-brand-primary" />
          <span>Đóng góp tài nguyên</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-brand-text">Đăng tải học liệu Toán lớp 3</h1>
        <p className="text-xs sm:text-sm text-brand-muted mt-1">
          Chia sẻ các bài giảng, phiếu bài tập hoặc trò chơi hữu ích cho cộng đồng giáo viên tiểu học. Mọi tài nguyên sẽ được kiểm duyệt trong 24 giờ.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Nhóm A – Thông tin cơ bản */}
        <div className="bg-white rounded-card border border-brand-border p-6 space-y-4">
          <h2 className="text-sm font-bold text-brand-deep uppercase tracking-wider flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-brand-light text-brand-primary flex items-center justify-center text-xs font-black">A</span>
            Thông tin cơ bản của học liệu
          </h2>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-brand-text mb-1">
                Tên học liệu <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="Ví dụ: Phiếu luyện tập bảng nhân 7 kết hợp trò chơi tìm ô số"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-brand-bg border border-brand-border rounded-btn focus:outline-none focus:border-brand-primary"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-brand-text mb-1">Mô tả ngắn gọn</label>
              <textarea
                rows={2}
                placeholder="Nêu tóm tắt cấu trúc học liệu, phương pháp áp dụng..."
                value={formData.description}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-brand-bg border border-brand-border rounded-btn focus:outline-none focus:border-brand-primary"
              />
            </div>
          </div>
        </div>

        {/* Nhóm B – Phân loại học liệu */}
        <div className="bg-white rounded-card border border-brand-border p-6 space-y-4">
          <h2 className="text-sm font-bold text-brand-deep uppercase tracking-wider flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-brand-light text-brand-primary flex items-center justify-center text-xs font-black">B</span>
            Phân loại sư phạm & Khung kiến thức
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-brand-text mb-1">Loại học liệu</label>
              <select
                value={formData.type}
                onChange={e => setFormData({ ...formData, type: e.target.value as ResourceType })}
                className="w-full px-3 py-2 text-xs bg-brand-bg border border-brand-border rounded-btn font-semibold"
              >
                <option value="worksheet">Phiếu bài tập (PDF/DOCX)</option>
                <option value="video">Video bài giảng</option>
                <option value="game">Trò chơi học tập</option>
                <option value="interactive">Bài tập tương tác</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-brand-text mb-1">Mạch kiến thức Toán 3</label>
              <select
                value={formData.categoryId}
                onChange={e => setFormData({ ...formData, categoryId: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-brand-bg border border-brand-border rounded-btn font-semibold"
              >
                {categories.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-brand-text mb-1">Mức độ nhận thức</label>
              <select
                value={formData.cognitiveLevel}
                onChange={e => setFormData({ ...formData, cognitiveLevel: e.target.value as CognitiveLevel })}
                className="w-full px-3 py-2 text-xs bg-brand-bg border border-brand-border rounded-btn font-semibold"
              >
                <option value="nhan_biet">Nhận biết</option>
                <option value="thong_hieu">Thông hiểu</option>
                <option value="van_dung">Vận dụng</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-brand-text mb-1">Giai đoạn dạy học</label>
              <select
                value={formData.teachingStage}
                onChange={e => setFormData({ ...formData, teachingStage: e.target.value as TeachingStage })}
                className="w-full px-3 py-2 text-xs bg-brand-bg border border-brand-border rounded-btn font-semibold"
              >
                <option value="khoi_dong">Khởi động</option>
                <option value="kham_pha">Khám phá</option>
                <option value="luyen_tap">Luyện tập</option>
                <option value="van_dung">Vận dụng</option>
                <option value="cung_co">Củng cố</option>
              </select>
            </div>
          </div>
        </div>

        {/* Nhóm C – Tệp & Liên kết */}
        <div className="bg-white rounded-card border border-brand-border p-6 space-y-4">
          <h2 className="text-sm font-bold text-brand-deep uppercase tracking-wider flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-brand-light text-brand-primary flex items-center justify-center text-xs font-black">C</span>
            Tệp đính kèm hoặc Liên kết Drive/YouTube
          </h2>

          <div className="border-2 border-dashed border-brand-sky/60 rounded-xl p-8 text-center bg-brand-ice/40 hover:bg-brand-ice transition-colors cursor-pointer">
            <UploadCloud className="w-10 h-10 text-brand-primary mx-auto mb-2" />
            <div className="text-xs font-bold text-brand-text">Kéo thả tệp PDF, MP4, PPTX vào đây, hoặc nhấn để chọn tệp</div>
            <div className="text-[11px] text-brand-muted mt-1">Hỗ trợ PDF, DOCX, MP4, ZIP (Tối đa 50MB)</div>
          </div>

          <div>
            <label className="block text-xs font-bold text-brand-text mb-1">Hoặc nhập liên kết chia sẻ (Google Drive / YouTube)</label>
            <input
              type="url"
              placeholder="https://drive.google.com/file/... hoặc https://youtube.com/watch?v=..."
              value={formData.driveUrl}
              onChange={e => setFormData({ ...formData, driveUrl: e.target.value })}
              className="w-full px-3.5 py-2.5 text-xs bg-brand-bg border border-brand-border rounded-btn focus:outline-none focus:border-brand-primary"
            />
          </div>
        </div>

        {/* Nhóm D – Thông tin chuyên môn */}
        <div className="bg-white rounded-card border border-brand-border p-6 space-y-4">
          <h2 className="text-sm font-bold text-brand-deep uppercase tracking-wider flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-brand-light text-brand-primary flex items-center justify-center text-xs font-black">D</span>
            Thông tin chuyên môn sư phạm
          </h2>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-brand-text mb-1">
                Mục tiêu học tập cần đạt <span className="text-red-500">*</span>
              </label>
              <textarea
                rows={2}
                required
                placeholder="Ví dụ: Giúp học sinh thành thạo kỹ năng nhân nhẩm bảng nhân 7 và áp dụng vào giải toán có lời văn 1 bước..."
                value={formData.objective}
                onChange={e => setFormData({ ...formData, objective: e.target.value })}
                className="w-full px-3.5 py-2.5 text-xs bg-brand-bg border border-brand-border rounded-btn focus:outline-none focus:border-brand-primary"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-brand-text mb-1">Cách tổ chức hoạt động đề xuất</label>
              <textarea
                rows={2}
                placeholder="Gợi ý phân chia thời gian, hình thức hoạt động cá nhân hay nhóm..."
                value={formData.teachingGuide}
                onChange={e => setFormData({ ...formData, teachingGuide: e.target.value })}
                className="w-full px-3.5 py-2.5 text-xs bg-brand-bg border border-brand-border rounded-btn focus:outline-none focus:border-brand-primary"
              />
            </div>
          </div>
        </div>

        {/* Nhóm E – Nguồn & Xác nhận */}
        <div className="bg-white rounded-card border border-brand-border p-6 space-y-4">
          <h2 className="text-sm font-bold text-brand-deep uppercase tracking-wider flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-brand-light text-brand-primary flex items-center justify-center text-xs font-black">E</span>
            Xác nhận bản quyền và cam kết nội dung
          </h2>

          <label className="flex items-start gap-3 p-3 bg-brand-ice rounded-xl border border-brand-border cursor-pointer">
            <input
              type="checkbox"
              checked={formData.confirmed}
              onChange={e => setFormData({ ...formData, confirmed: e.target.checked })}
              className="rounded text-brand-primary focus:ring-brand-primary h-4 w-4 border-brand-border mt-0.5"
            />
            <span className="text-xs text-slate-700 leading-relaxed">
              Tôi xác nhận học liệu này do tôi biên soạn hoặc có quyền sử dụng hợp pháp theo quy định giáo dục, không chứa mã độc, nội dung thương mại trái phép hoặc vi phạm chuẩn mực sư phạm.
            </span>
          </label>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={() => setActiveTab('library')}
            className="px-5 py-2.5 bg-white border border-brand-border text-brand-text text-xs font-semibold rounded-btn hover:bg-brand-ice"
          >
            Hủy bỏ
          </button>
          <button
            type="submit"
            className="px-6 py-2.5 bg-brand-primary hover:bg-brand-deep text-white text-xs font-bold rounded-btn shadow-soft transition-all flex items-center gap-2"
          >
            <CheckCircle className="w-4 h-4" />
            Gửi kiểm duyệt học liệu
          </button>
        </div>

      </form>

    </div>
  );
};
