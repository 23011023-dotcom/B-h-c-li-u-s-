import React, { useState } from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  Search, 
  Video, 
  FileText, 
  Gamepad2, 
  MousePointerClick, 
  BookOpen, 
  Layers, 
  Download, 
  CheckCircle2, 
  UploadCloud,
  ChevronRight,
  TrendingUp,
  School
} from 'lucide-react';
import { useResources } from '../context/ResourceContext';
import { ResourceCard } from '../components/ResourceCard';
import { ResourceType } from '../types';

export const HomePage: React.FC = () => {
  const { resources, setActiveTab, setFilters } = useResources();
  const [quickKeyword, setQuickKeyword] = useState('');

  const approvedResources = resources.filter(r => r.status === 'approved');
  const featuredResources = approvedResources.slice(0, 4);
  const latestResources = [...approvedResources].reverse().slice(0, 4);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setFilters(prev => ({ ...prev, keyword: quickKeyword }));
    setActiveTab('library');
  };

  const handleCategoryCardClick = (type: ResourceType) => {
    setFilters(prev => ({ ...prev, types: [type], keyword: '' }));
    setActiveTab('library');
  };

  // Stats
  const totalRes = approvedResources.length;
  const totalVideo = approvedResources.filter(r => r.type === 'video').length;
  const totalWorksheet = approvedResources.filter(r => r.type === 'worksheet').length;
  const totalGame = approvedResources.filter(r => r.type === 'game' || r.type === 'interactive').length;

  return (
    <div className="space-y-12 pb-12">
      
      {/* 3.1.B Banner Giới thiệu Hero */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#EAF5FF] via-[#DDF1FF] to-[#C8E7FF] border border-brand-border p-8 md:p-12 shadow-soft">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Cột trái: Nội dung & Nút kêu gọi */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/80 backdrop-blur-xs text-brand-deep text-xs font-bold border border-brand-sky/30 shadow-xs">
              <Sparkles className="w-4 h-4 text-brand-sky" />
              <span>NỀN TẢNG HỌC LIỆU MỞ – CHUẨN GDPT 2018</span>
            </div>
            
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-brand-text tracking-tight leading-tight">
              KHO HỌC LIỆU SỐ <br />
              <span className="text-brand-primary">TOÁN LỚP 3</span>
            </h1>

            <p className="text-base sm:text-lg text-brand-muted font-medium leading-relaxed max-w-xl">
              Khơi nguồn sáng tạo – Lan tỏa niềm vui học Toán! Khám phá kho video bài giảng, phiếu bài tập và trò chơi học tập thiết kế riêng cho mạch kiến thức <strong>Số và Phép tính lớp 3</strong>.
            </p>

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => setActiveTab('library')}
                className="px-6 py-3 bg-brand-primary text-white text-sm font-bold rounded-btn shadow-soft hover:bg-brand-deep hover:shadow-card-hover transition-all flex items-center gap-2"
              >
                Khám phá ngay
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => setActiveTab('upload')}
                className="px-6 py-3 bg-white text-brand-primary text-sm font-bold rounded-btn border border-brand-sky/40 hover:bg-brand-ice transition-all flex items-center gap-2"
              >
                <UploadCloud className="w-4 h-4" />
                Chia sẻ học liệu
              </button>
            </div>

            {/* Quick search form right inside hero */}
            <form onSubmit={handleSearch} className="pt-2">
              <div className="bg-white rounded-xl p-1.5 border border-brand-border shadow-soft flex items-center max-w-md">
                <Search className="w-5 h-5 text-brand-muted ml-2" />
                <input
                  type="text"
                  placeholder="Nhập tên bài học (vd: Bảng nhân 7, Rút về đơn vị)..."
                  value={quickKeyword}
                  onChange={(e) => setQuickKeyword(e.target.value)}
                  className="w-full px-3 py-2 text-xs md:text-sm text-brand-text placeholder-slate-400 focus:outline-none"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-brand-primary text-white text-xs font-bold rounded-lg hover:bg-brand-deep shrink-0 transition-colors"
                >
                  Tìm kiếm
                </button>
              </div>
            </form>
          </div>

          {/* Cột phải: Hình minh họa sinh động Toán 3 */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="w-full max-w-md bg-white/70 backdrop-blur-md rounded-2xl border border-white/80 p-6 shadow-card-hover space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-brand-border/60">
                <span className="text-xs font-bold text-brand-deep flex items-center gap-1.5">
                  <School className="w-4 h-4 text-brand-primary" /> Mạch kiến thức trọng tâm
                </span>
                <span className="text-[11px] font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                  100% Sư phạm
                </span>
              </div>
              
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-brand-ice/80 rounded-xl border border-brand-border">
                  <div className="font-extrabold text-brand-primary text-lg mb-1">100 000</div>
                  <div className="text-brand-muted font-medium">Phạm vi số tự nhiên lớp 3</div>
                </div>
                <div className="p-3 bg-purple-50 rounded-xl border border-purple-100">
                  <div className="font-extrabold text-purple-600 text-lg mb-1">2 ➜ 9</div>
                  <div className="text-brand-muted font-medium">Bảng nhân & Bảng chia</div>
                </div>
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100">
                  <div className="font-extrabold text-emerald-600 text-lg mb-1">2 Bước</div>
                  <div className="text-brand-muted font-medium">Bài toán rút về đơn vị</div>
                </div>
                <div className="p-3 bg-amber-50 rounded-xl border border-amber-100">
                  <div className="font-extrabold text-amber-600 text-lg mb-1">( ... )</div>
                  <div className="text-brand-muted font-medium">Biểu thức có dấu ngoặc</div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-gradient-to-r from-brand-primary to-brand-sky text-white flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold">Dành cho Giáo viên & Sinh viên SP</div>
                  <div className="text-[11px] text-blue-100">Sẵn sàng tải về sử dụng ngay</div>
                </div>
                <BookOpen className="w-6 h-6 opacity-80" />
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 3.1.D Khu vực Thống kê */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {[
          { label: 'Tổng số học liệu', count: 120 + totalRes, icon: Layers, color: 'text-brand-primary', bg: 'bg-blue-50' },
          { label: 'Video bài giảng', count: 35 + totalVideo, icon: Video, color: 'text-amber-500', bg: 'bg-amber-50' },
          { label: 'Phiếu bài tập', count: 68 + totalWorksheet, icon: FileText, color: 'text-emerald-500', bg: 'bg-emerald-50' },
          { label: 'Trò chơi & Tương tác', count: 24 + totalGame, icon: Gamepad2, color: 'text-purple-500', bg: 'bg-purple-50' },
        ].map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <div
              key={idx}
              className="bg-white rounded-card border border-[#DCEBFA] p-5 flex items-center gap-4 transition-all hover:shadow-soft"
            >
              <div className={`w-12 h-12 rounded-full ${stat.bg} ${stat.color} flex items-center justify-center shrink-0`}>
                <Icon className="w-6 h-6" />
              </div>
              <div>
                <div className="text-2xl font-black text-brand-deep tracking-tight">{stat.count}</div>
                <div className="text-xs font-medium text-brand-muted">{stat.label}</div>
              </div>
            </div>
          );
        })}
      </section>

      {/* 3.1.E Khám phá theo loại học liệu (4 thẻ lớn) */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-brand-text">Khám phá theo loại học liệu</h2>
            <p className="text-xs sm:text-sm text-brand-muted">Chọn định dạng tài nguyên phù hợp với từng hoạt động dạy học</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {[
            {
              type: 'video' as ResourceType,
              title: 'Video bài giảng',
              desc: 'Hoạt hình trực quan, bài hát vui nhộn kích thích tư duy toán học',
              count: '35+ video',
              bg: 'bg-[#FFF7E8]',
              border: 'border-amber-200',
              iconColor: 'text-amber-600',
              icon: Video,
            },
            {
              type: 'worksheet' as ResourceType,
              title: 'Phiếu bài tập',
              desc: 'Được phân hóa 3 mức độ nhận thức, sẵn sàng in ấn chất lượng cao',
              count: '68+ phiếu',
              bg: 'bg-[#EAF8F0]',
              border: 'border-emerald-200',
              iconColor: 'text-emerald-600',
              icon: FileText,
            },
            {
              type: 'game' as ResourceType,
              title: 'Trò chơi học tập',
              desc: 'Mini game rèn tính nhẩm nhanh, tạo không khí hào hứng trong lớp học',
              count: '16+ game',
              bg: 'bg-[#F3EDFF]',
              border: 'border-purple-200',
              iconColor: 'text-purple-600',
              icon: Gamepad2,
            },
            {
              type: 'interactive' as ResourceType,
              title: 'Bài tập tương tác',
              desc: 'Mô phỏng bàn tính, trục số và khối Dienes kéo thả trực quan',
              count: '12+ tương tác',
              bg: 'bg-[#E8F8FC]',
              border: 'border-cyan-200',
              iconColor: 'text-cyan-600',
              icon: MousePointerClick,
            },
          ].map((cat) => {
            const Icon = cat.icon;
            return (
              <div
                key={cat.type}
                onClick={() => handleCategoryCardClick(cat.type)}
                className={`${cat.bg} rounded-card border ${cat.border} p-5 cursor-pointer transition-all duration-300 hover:scale-102 hover:shadow-card-hover flex flex-col justify-between`}
              >
                <div>
                  <div className={`w-12 h-12 rounded-xl bg-white flex items-center justify-center ${cat.iconColor} shadow-xs mb-3`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-brand-text mb-1">{cat.title}</h3>
                  <p className="text-xs text-brand-muted leading-relaxed mb-4">{cat.desc}</p>
                </div>
                <div className="flex items-center justify-between text-xs font-semibold text-brand-deep pt-3 border-t border-black/5">
                  <span>{cat.count}</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3.1.F Học liệu nổi bật */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-brand-text">Học liệu nổi bật & Được đánh giá cao</h2>
            <p className="text-xs sm:text-sm text-brand-muted">Những tài nguyên được đông đảo giáo viên tin dùng trong giảng dạy</p>
          </div>
          <button
            onClick={() => setActiveTab('library')}
            className="text-xs sm:text-sm font-bold text-brand-primary hover:text-brand-deep flex items-center gap-1"
          >
            Xem tất cả
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {featuredResources.map(res => (
            <ResourceCard key={res.id} resource={res} />
          ))}
        </div>
      </section>

      {/* 3.1.G Học liệu mới cập nhật */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-brand-text">Học liệu mới cập nhật</h2>
            <p className="text-xs sm:text-sm text-brand-muted">Các tài nguyên bài giảng mới nhất vừa qua khâu kiểm duyệt</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {latestResources.map(res => (
            <ResourceCard key={res.id} resource={res} />
          ))}
        </div>
      </section>

      {/* 3.1.H Khu vực kêu gọi đóng góp */}
      <section className="rounded-3xl bg-brand-deep text-white p-8 sm:p-10 relative overflow-hidden shadow-soft">
        <div className="relative z-10 max-w-2xl space-y-4 text-left">
          <div className="inline-block px-3 py-1 rounded-full bg-white/10 text-brand-sky text-xs font-bold uppercase tracking-wider">
            Cộng đồng chia sẻ học liệu
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Cùng xây dựng cộng đồng học liệu Toán 3!
          </h2>
          <p className="text-sm text-blue-100/90 leading-relaxed">
            Mỗi học liệu được chia sẻ là một nguồn tài nguyên quý giá đồng hành cùng hàng ngàn giáo viên tiểu học trên khắp mọi miền đất nước.
          </p>
          <div className="pt-2">
            <button
              onClick={() => setActiveTab('upload')}
              className="px-6 py-3 bg-white text-brand-deep hover:bg-brand-light font-bold text-sm rounded-btn shadow-md transition-all inline-flex items-center gap-2"
            >
              <UploadCloud className="w-4 h-4 text-brand-primary" />
              Đăng tải học liệu ngay
            </button>
          </div>
        </div>
      </section>

    </div>
  );
};
