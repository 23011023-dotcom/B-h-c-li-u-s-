import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  BookMarked, 
  Heart, 
  Download, 
  Bell, 
  Settings, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  PlusCircle, 
  Trash2, 
  Eye, 
  ExternalLink 
} from 'lucide-react';
import { useResources } from '../context/ResourceContext';
import { useAuth } from '../context/AuthContext';
import { ResourceCard } from '../components/ResourceCard';

export const UserDashboard: React.FC = () => {
  const { resources, favorites, setActiveTab, setSelectedResourceId, showToast } = useResources();
  const { user } = useAuth();
  const [subTab, setSubTab] = useState<'my_resources' | 'favorites' | 'history'>('my_resources');

  const myResources = resources.filter(r => r.authorName.includes('Hà') || r.authorId === user?.id);
  const favoriteResources = resources.filter(r => favorites.includes(r.id));

  const totalUploaded = myResources.length;
  const approvedCount = myResources.filter(r => r.status === 'approved').length;
  const pendingCount = myResources.filter(r => r.status === 'pending').length;
  const totalDownloads = myResources.reduce((acc, r) => acc + r.downloadCount, 0);

  return (
    <div className="space-y-6 pb-12 text-left">
      
      {/* Dashboard Header */}
      <div className="bg-white rounded-2xl border border-brand-border p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <img
            src={user?.avatarUrl}
            alt={user?.fullName}
            className="w-14 h-14 rounded-full object-cover border-2 border-brand-primary"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-extrabold text-brand-text">{user?.fullName}</h1>
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-blue-100 text-brand-deep">
                Giáo viên Tiểu học
              </span>
            </div>
            <p className="text-xs text-brand-muted mt-0.5">{user?.schoolName}</p>
          </div>
        </div>

        <button
          onClick={() => setActiveTab('upload')}
          className="px-5 py-2.5 bg-brand-primary hover:bg-brand-deep text-white text-xs font-bold rounded-btn shadow-soft transition-all inline-flex items-center gap-2 shrink-0 self-start md:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          Đăng tải học liệu mới
        </button>
      </div>

      {/* 4 Statistics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Học liệu đã đăng', val: totalUploaded, icon: BookMarked, color: 'text-brand-primary', bg: 'bg-blue-50' },
          { label: 'Được phê duyệt', val: approvedCount, icon: CheckCircle2, color: 'text-emerald-500', bg: 'bg-emerald-50' },
          { label: 'Đang chờ duyệt', val: pendingCount, icon: Clock, color: 'text-amber-500', bg: 'bg-amber-50' },
          { label: 'Tổng lượt tải về', val: totalDownloads, icon: Download, color: 'text-purple-500', bg: 'bg-purple-50' },
        ].map((item, idx) => {
          const Icon = item.icon;
          return (
            <div key={idx} className="bg-white rounded-xl border border-brand-border p-4 flex items-center gap-3">
              <div className={`w-10 h-10 rounded-lg ${item.bg} ${item.color} flex items-center justify-center shrink-0`}>
                <Icon className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xl font-black text-brand-deep">{item.val}</div>
                <div className="text-[11px] font-medium text-brand-muted">{item.label}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Tabs Menu */}
      <div className="flex border-b border-brand-border space-x-4 text-xs font-bold">
        {[
          { id: 'my_resources', label: `Học liệu của tôi (${myResources.length})`, icon: BookMarked },
          { id: 'favorites', label: `Học liệu yêu thích (${favoriteResources.length})`, icon: Heart },
          { id: 'history', label: 'Lịch sử tải xuống (6)', icon: Download },
        ].map(t => {
          const Icon = t.icon;
          const isActive = subTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setSubTab(t.id as any)}
              className={`pb-3 px-1 flex items-center gap-1.5 transition-colors relative ${
                isActive ? 'text-brand-primary border-b-2 border-brand-primary' : 'text-brand-muted hover:text-brand-text'
              }`}
            >
              <Icon className="w-4 h-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      {subTab === 'my_resources' && (
        <div className="bg-white rounded-card border border-brand-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-brand-ice/60 border-b border-brand-border text-brand-deep font-bold">
                <tr>
                  <th className="p-3.5">Tên học liệu & Chủ đề</th>
                  <th className="p-3.5">Định dạng</th>
                  <th className="p-3.5">Ngày đăng</th>
                  <th className="p-3.5">Trạng thái</th>
                  <th className="p-3.5">Lượt tải</th>
                  <th className="p-3.5 text-right">Thao tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-border">
                {myResources.map(r => (
                  <tr key={r.id} className="hover:bg-brand-ice/30 transition-colors">
                    <td className="p-3.5">
                      <div className="font-bold text-brand-text">{r.title}</div>
                      <div className="text-[11px] text-brand-muted">{r.categoryName}</div>
                    </td>
                    <td className="p-3.5 font-medium uppercase text-[11px] text-brand-muted">
                      {r.type}
                    </td>
                    <td className="p-3.5 text-brand-muted">
                      {new Date(r.createdAt).toLocaleDateString('vi-VN')}
                    </td>
                    <td className="p-3.5">
                      {r.status === 'approved' ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                          <CheckCircle2 className="w-3 h-3" /> Đã duyệt
                        </span>
                      ) : r.status === 'pending' ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
                          <Clock className="w-3 h-3" /> Chờ duyệt
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-red-700 bg-red-50 px-2 py-0.5 rounded-full">
                          <XCircle className="w-3 h-3" /> Từ chối
                        </span>
                      )}
                    </td>
                    <td className="p-3.5 font-bold text-brand-text">{r.downloadCount}</td>
                    <td className="p-3.5 text-right space-x-2">
                      <button
                        onClick={() => {
                          setSelectedResourceId(r.id);
                          setActiveTab('detail');
                        }}
                        className="text-brand-primary hover:text-brand-deep font-semibold"
                      >
                        Xem
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {subTab === 'favorites' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {favoriteResources.map(res => (
            <ResourceCard key={res.id} resource={res} />
          ))}
        </div>
      )}

      {subTab === 'history' && (
        <div className="bg-white rounded-card border border-brand-border p-8 text-center text-xs text-brand-muted space-y-2">
          <Download className="w-8 h-8 text-brand-primary mx-auto" />
          <div className="font-bold text-brand-text">Bạn đã tải 6 tài liệu trong tuần này</div>
          <p>Tất cả tài liệu được cấp quyền sử dụng cho hoạt động giảng dạy tiểu học.</p>
        </div>
      )}

    </div>
  );
};
