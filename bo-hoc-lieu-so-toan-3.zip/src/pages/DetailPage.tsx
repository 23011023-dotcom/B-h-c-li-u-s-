import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Download, 
  Heart, 
  Share2, 
  Star, 
  Clock, 
  School, 
  Award, 
  CheckCircle2, 
  FileText, 
  Video, 
  Gamepad2, 
  MousePointerClick, 
  MessageCircle, 
  Send,
  AlertCircle,
  Play,
  RotateCcw
} from 'lucide-react';
import { useResources } from '../context/ResourceContext';
import { useAuth } from '../context/AuthContext';
import { ResourceCard } from '../components/ResourceCard';

export const DetailPage: React.FC = () => {
  const { 
    resources, 
    selectedResourceId, 
    setActiveTab, 
    downloadResource, 
    favorites, 
    toggleFavorite,
    showToast 
  } = useResources();
  const { user } = useAuth();

  const [rating, setRating] = useState<number>(5);
  const [commentText, setCommentText] = useState<string>('');
  const [comments, setComments] = useState<Array<{ id: string; author: string; role: string; date: string; content: string }>>([
    {
      id: 'c-1',
      author: 'Cô Mai Thị Huệ (Tiểu học Chu Văn An)',
      role: 'Giáo viên lớp 3',
      date: 'Hôm qua',
      content: 'Học liệu rất sát với thực tế giảng dạy trên lớp. Học sinh rất hào hứng khi được tương tác trực quan.'
    },
    {
      id: 'c-2',
      author: 'Thầy Lê Văn Hùng (Tiểu học Thực nghiệm)',
      role: 'Tổ trưởng chuyên môn',
      date: '3 ngày trước',
      content: 'Hình ảnh sắc nét, các bài toán phân hóa nhận biết và vận dụng rất rõ ràng. Đã tải về cho các giáo viên trong khối sử dụng.'
    }
  ]);

  // Mini-game state for interactive / game simulation preview
  const [gameScore, setGameScore] = useState<number>(0);
  const [gameQuestionIndex, setGameQuestionIndex] = useState<number>(0);
  const mathQuestions = [
    { q: '3 x 7 = ?', options: ['21', '24', '18', '27'], correct: '21' },
    { q: '63 : 7 = ?', options: ['8', '9', '7', '6'], correct: '9' },
    { q: 'Số gồm 5 chục nghìn, 4 nghìn, 2 trăm và 8 đơn vị là:', options: ['54208', '5428', '54028', '50428'], correct: '54208' },
  ];

  const resource = resources.find(r => r.id === selectedResourceId) || resources[0];
  const relatedResources = resources.filter(r => r.categoryId === resource.categoryId && r.id !== resource.id).slice(0, 3);
  const isFavorite = favorites.includes(resource.id);

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    setComments(prev => [
      {
        id: 'c-' + Date.now(),
        author: user?.fullName || 'Giáo viên Toán',
        role: user?.schoolName || 'Giáo viên Tiểu học',
        date: 'Vừa xong',
        content: commentText.trim(),
      },
      ...prev
    ]);
    setCommentText('');
    showToast('Bình luận của bạn đã được đăng thành công!', 'success');
  };

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    showToast('Đã sao chép liên kết học liệu vào bộ nhớ tạm!', 'info');
  };

  return (
    <div className="space-y-8 pb-12 text-left">
      
      {/* Back button */}
      <div>
        <button
          onClick={() => setActiveTab('library')}
          className="inline-flex items-center gap-2 text-xs font-bold text-brand-primary hover:text-brand-deep transition-colors bg-white px-3 py-1.5 rounded-lg border border-brand-border shadow-xs"
        >
          <ArrowLeft className="w-4 h-4" />
          Quay lại kho học liệu
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Cột trái (8 cols): Xem trước & Thông tin & Thảo luận */}
        <div className="lg:col-span-8 space-y-8">
          
          {/* Phần 1: Khu vực xem trước học liệu */}
          <div className="bg-white rounded-2xl border border-brand-border overflow-hidden shadow-soft">
            <div className="p-4 bg-brand-ice border-b border-brand-border flex items-center justify-between">
              <span className="text-xs font-bold text-brand-deep flex items-center gap-1.5">
                <Play className="w-4 h-4 text-brand-primary" />
                Khung xem trước học liệu trực tiếp
              </span>
              <span className="text-[11px] font-semibold text-brand-muted bg-white px-2 py-0.5 rounded border border-brand-border">
                {resource.fileFormat}
              </span>
            </div>

            {/* Preview player / simulation */}
            <div className="p-4 sm:p-6 bg-slate-900 flex items-center justify-center min-h-[340px] text-white">
              {resource.type === 'video' ? (
                <div className="w-full aspect-video rounded-xl overflow-hidden bg-black flex flex-col items-center justify-center relative group">
                  <img
                    src={resource.thumbnailUrl}
                    alt={resource.title}
                    className="w-full h-full object-cover opacity-60"
                  />
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <button 
                      onClick={() => showToast('Đang phát video mô phỏng bài giảng Toán 3...', 'info')}
                      className="w-16 h-16 rounded-full bg-brand-primary text-white flex items-center justify-center hover:scale-110 transition-transform shadow-lg"
                    >
                      <Play className="w-8 h-8 fill-white ml-1" />
                    </button>
                    <span className="mt-3 text-xs font-semibold bg-black/60 px-3 py-1 rounded-full">
                      Bấm để phát bài giảng hoạt hình ({resource.durationMinutes} phút)
                    </span>
                  </div>
                </div>
              ) : resource.type === 'game' || resource.type === 'interactive' ? (
                /* Mini math interactive simulator */
                <div className="w-full max-w-lg bg-slate-800 rounded-xl p-6 border border-slate-700 text-center space-y-4">
                  <div className="flex items-center justify-between text-xs text-brand-sky pb-2 border-b border-slate-700">
                    <span className="font-bold flex items-center gap-1">
                      <Gamepad2 className="w-4 h-4" /> Mô phỏng trò chơi Toán 3
                    </span>
                    <span>Điểm: {gameScore}</span>
                  </div>
                  
                  <div className="py-4">
                    <div className="text-xs text-slate-400 mb-1">Câu hỏi số {gameQuestionIndex + 1}/{mathQuestions.length}:</div>
                    <div className="text-2xl font-black text-white">{mathQuestions[gameQuestionIndex]?.q}</div>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    {mathQuestions[gameQuestionIndex]?.options.map((opt, i) => (
                      <button
                        key={i}
                        onClick={() => {
                          if (opt === mathQuestions[gameQuestionIndex].correct) {
                            setGameScore(s => s + 10);
                            showToast('Chính xác! +10 điểm', 'success');
                          } else {
                            showToast('Chưa đúng rồi! Hãy thử lại.', 'warning');
                          }
                          setGameQuestionIndex((idx) => (idx + 1) % mathQuestions.length);
                        }}
                        className="py-2.5 bg-slate-700 hover:bg-brand-primary text-white font-bold rounded-lg text-sm transition-colors border border-slate-600"
                      >
                        {opt}
                      </button>
                    ))}
                  </div>

                  <div className="text-[11px] text-slate-400 pt-2 flex items-center justify-center gap-2">
                    <RotateCcw className="w-3.5 h-3.5 cursor-pointer hover:text-white" onClick={() => { setGameScore(0); setGameQuestionIndex(0); }} />
                    <span>Học sinh có thể trải nghiệm trực tiếp trên máy tính hoặc máy tính bảng</span>
                  </div>
                </div>
              ) : (
                /* PDF Worksheet preview */
                <div className="w-full max-w-md bg-white rounded-xl p-6 text-slate-800 shadow-lg space-y-4 border border-slate-300">
                  <div className="border-b-2 border-brand-primary pb-3 text-center">
                    <div className="text-[11px] font-bold text-brand-primary uppercase">Trường Tiểu học ........................</div>
                    <div className="text-base font-extrabold text-brand-deep">{resource.title}</div>
                    <div className="text-xs text-slate-500">Họ và tên học sinh: ....................................... Lớp 3.....</div>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="p-2 bg-slate-50 rounded border border-slate-200">
                      <strong>Bài 1 (Nhận biết):</strong> Tính nhẩm: 7 x 4 = ... ; 56 : 7 = ... ; 7 x 8 = ...
                    </div>
                    <div className="p-2 bg-slate-50 rounded border border-slate-200">
                      <strong>Bài 2 (Thông hiểu):</strong> Có 28 quả cam xếp đều vào 7 đĩa. Hỏi mỗi đĩa có bao nhiêu quả cam?
                    </div>
                    <div className="p-2 bg-slate-50 rounded border border-slate-200">
                      <strong>Bài 3 (Vận dụng):</strong> Một cửa hàng có 63m vải, đã bán 1/7 số vải đó. Hỏi cửa hàng còn lại bao nhiêu mét vải?
                    </div>
                  </div>
                  <div className="text-center pt-2">
                    <button
                      onClick={() => downloadResource(resource.id)}
                      className="px-4 py-2 bg-brand-primary text-white text-xs font-bold rounded-lg hover:bg-brand-deep transition-all inline-flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5" /> Tải về bản in PDF chất lượng cao
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Phần 2: Thông tin chuyên môn chi tiết */}
          <div className="bg-white rounded-2xl border border-brand-border p-6 shadow-xs space-y-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2.5 py-1 rounded bg-brand-light text-brand-primary font-bold text-xs">
                  {resource.categoryName}
                </span>
                {resource.lessonName && (
                  <span className="px-2.5 py-1 rounded bg-slate-100 text-slate-700 font-semibold text-xs">
                    {resource.lessonName}
                  </span>
                )}
              </div>
              <h1 className="text-2xl font-extrabold text-brand-text mb-2">{resource.title}</h1>
              <p className="text-sm text-brand-muted leading-relaxed">{resource.description}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-4 border-t border-brand-border">
              <div className="space-y-1">
                <span className="font-bold text-brand-deep uppercase tracking-wider block">Mục tiêu sử dụng</span>
                <p className="text-slate-700 leading-relaxed bg-brand-bg p-3 rounded-lg border border-brand-border">
                  {resource.objective}
                </p>
              </div>
              <div className="space-y-1">
                <span className="font-bold text-brand-deep uppercase tracking-wider block">Hướng dẫn tổ chức hoạt động</span>
                <p className="text-slate-700 leading-relaxed bg-brand-bg p-3 rounded-lg border border-brand-border">
                  {resource.teachingGuide}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-xs text-brand-muted pt-3 border-t border-brand-border">
              <span className="flex items-center gap-1.5">
                <School className="w-4 h-4 text-brand-primary" />
                Đóng góp: <strong>{resource.authorName}</strong> ({resource.authorSchool})
              </span>
              <span className="flex items-center gap-1.5">
                <Award className="w-4 h-4 text-brand-primary" />
                {resource.copyrightInfo}
              </span>
            </div>
          </div>

          {/* Phần 4: Đánh giá và bình luận */}
          <div className="bg-white rounded-2xl border border-brand-border p-6 shadow-xs space-y-6">
            <h3 className="text-lg font-bold text-brand-text flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-brand-primary" />
              Đánh giá & Bình luận từ giáo viên
            </h3>

            {/* Input comment */}
            <form onSubmit={handleAddComment} className="space-y-3">
              <div className="flex items-center gap-2 text-xs font-semibold text-brand-text">
                <span>Đánh giá của bạn:</span>
                <div className="flex gap-1 text-amber-400">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      type="button"
                      key={star}
                      onClick={() => setRating(star)}
                      className="focus:outline-none"
                    >
                      <Star className={`w-5 h-5 ${star <= rating ? 'fill-amber-400' : 'text-slate-300'}`} />
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2">
                <textarea
                  rows={2}
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Chia sẻ nhận xét về tính thực tế, độ phân hóa hoặc gợi ý sử dụng trong giờ học..."
                  className="w-full text-xs sm:text-sm p-3 bg-brand-bg border border-brand-border rounded-lg text-brand-text focus:outline-none focus:border-brand-primary"
                />
                <button
                  type="submit"
                  className="px-4 bg-brand-primary text-white rounded-lg hover:bg-brand-deep transition-colors flex items-center justify-center shrink-0"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </form>

            {/* Comment list */}
            <div className="space-y-4 pt-2">
              {comments.map((c) => (
                <div key={c.id} className="p-3.5 bg-brand-bg rounded-xl border border-brand-border text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-brand-text">{c.author}</span>
                    <span className="text-[11px] text-brand-muted">{c.date}</span>
                  </div>
                  <div className="text-[11px] text-brand-primary font-medium">{c.role}</div>
                  <p className="text-slate-700 leading-relaxed pt-1">{c.content}</p>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Cột phải (4 cols): Thanh thao tác & Học liệu liên quan */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Thanh thao tác Actions */}
          <div className="bg-white rounded-2xl border border-brand-border p-6 shadow-soft space-y-4">
            <h3 className="font-bold text-base text-brand-text pb-2 border-b border-brand-border">
              Thao tác với học liệu
            </h3>

            <button
              onClick={() => downloadResource(resource.id)}
              className="w-full py-3 bg-brand-primary hover:bg-brand-deep text-white font-bold text-sm rounded-btn shadow-soft transition-all flex items-center justify-center gap-2"
            >
              <Download className="w-5 h-5" />
              Tải xuống tệp ({resource.fileSize})
            </button>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => toggleFavorite(resource.id)}
                className={`py-2 px-3 border rounded-btn text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                  isFavorite 
                    ? 'border-red-200 bg-red-50 text-red-600' 
                    : 'border-brand-border hover:bg-brand-ice text-brand-text'
                }`}
              >
                <Heart className={`w-4 h-4 ${isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
                {isFavorite ? 'Đã yêu thích' : 'Lưu học liệu'}
              </button>

              <button
                onClick={handleShare}
                className="py-2 px-3 border border-brand-border hover:bg-brand-ice rounded-btn text-xs font-semibold text-brand-text flex items-center justify-center gap-1.5 transition-colors"
              >
                <Share2 className="w-4 h-4 text-brand-primary" />
                Chia sẻ
              </button>
            </div>

            <div className="p-3 bg-brand-ice rounded-xl border border-brand-border text-xs space-y-2">
              <div className="flex justify-between text-brand-muted">
                <span>Dung lượng:</span>
                <strong className="text-brand-text">{resource.fileSize}</strong>
              </div>
              <div className="flex justify-between text-brand-muted">
                <span>Lượt tải xuống:</span>
                <strong className="text-brand-text">{resource.downloadCount} lượt</strong>
              </div>
              <div className="flex justify-between text-brand-muted">
                <span>Đánh giá:</span>
                <strong className="text-amber-500 font-bold">{resource.ratingAverage} ★ ({resource.ratingCount} lượt)</strong>
              </div>
              <div className="flex justify-between text-brand-muted">
                <span>Định dạng:</span>
                <strong className="text-brand-text">{resource.fileFormat}</strong>
              </div>
            </div>
          </div>

          {/* Phần 5: Học liệu liên quan */}
          <div className="space-y-3">
            <h3 className="font-bold text-sm text-brand-deep uppercase tracking-wider">
              Học liệu cùng chủ đề
            </h3>
            <div className="space-y-4">
              {relatedResources.map(res => (
                <ResourceCard key={res.id} resource={res} />
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
