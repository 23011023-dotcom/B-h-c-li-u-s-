import React from 'react';
import { 
  Search, 
  ArrowUpDown, 
  BookOpen, 
  Layers, 
  Filter, 
  Sparkles,
  RotateCcw 
} from 'lucide-react';
import { useResources } from '../context/ResourceContext';
import { ResourceFilter } from '../components/ResourceFilter';
import { ResourceCard } from '../components/ResourceCard';

export const LibraryPage: React.FC = () => {
  const { 
    filteredResources, 
    filters, 
    setFilters, 
    resetFilters,
    categories 
  } = useResources();

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilters(prev => ({ ...prev, keyword: e.target.value, page: 1 }));
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilters(prev => ({ ...prev, sortBy: e.target.value as any }));
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header Kho học liệu */}
      <div className="bg-white rounded-2xl border border-brand-border p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-brand-sky uppercase tracking-wider mb-1">
            <Layers className="w-4 h-4 text-brand-primary" />
            <span>Kho tài nguyên mở</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-brand-text">Kho học liệu số Toán lớp 3</h1>
          <p className="text-xs sm:text-sm text-brand-muted mt-1">
            Khám phá tài nguyên phục vụ dạy học Số và Phép tính Toán 3 theo chuẩn GDPT 2018.
          </p>
        </div>

        {/* Search input bar */}
        <div className="w-full md:w-96 relative">
          <input
            type="text"
            placeholder="Nhập tên bài học hoặc từ khóa..."
            value={filters.keyword}
            onChange={handleSearchChange}
            className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-brand-bg border border-brand-border rounded-btn text-brand-text focus:outline-none focus:border-brand-primary transition-all"
          />
          <Search className="w-4 h-4 text-brand-muted absolute left-3.5 top-3" />
        </div>
      </div>

      {/* Main Grid: Sidebar + Resources */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        
        {/* Sidebar Bộ lọc */}
        <div className="lg:col-span-1">
          <ResourceFilter />
        </div>

        {/* Kết quả học liệu */}
        <div className="lg:col-span-3 space-y-5">
          
          {/* Controls Bar: Count & Sort */}
          <div className="bg-white rounded-xl border border-brand-border px-4 py-3 flex items-center justify-between text-xs sm:text-sm">
            <div className="font-semibold text-brand-text">
              Tìm thấy <span className="text-brand-primary font-bold">{filteredResources.length}</span> học liệu
              {filters.keyword && <span> cho từ khóa "{filters.keyword}"</span>}
            </div>

            <div className="flex items-center gap-2">
              <span className="text-brand-muted hidden sm:inline">Sắp xếp:</span>
              <select
                value={filters.sortBy}
                onChange={handleSortChange}
                className="bg-brand-bg border border-brand-border rounded-lg px-2.5 py-1.5 text-xs font-semibold text-brand-text focus:outline-none focus:border-brand-primary"
              >
                <option value="newest">Mới nhất ↓</option>
                <option value="oldest">Cũ nhất ↑</option>
                <option value="rating">Đánh giá cao nhất ★</option>
                <option value="downloads">Tải xuống nhiều nhất</option>
              </select>
            </div>
          </div>

          {/* Resource Grid */}
          {filteredResources.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
              {filteredResources.map(res => (
                <ResourceCard key={res.id} resource={res} />
              ))}
            </div>
          ) : (
            /* Empty State */
            <div className="bg-white rounded-2xl border border-brand-border p-12 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-brand-light text-brand-primary mx-auto flex items-center justify-center">
                <BookOpen className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-brand-text">Không tìm thấy học liệu phù hợp</h3>
              <p className="text-xs sm:text-sm text-brand-muted max-w-md mx-auto">
                Hãy thử nới lỏng các tiêu chí trong bộ lọc bên trái hoặc nhập từ khóa bài học khác như "bảng nhân", "phép cộng", "biểu thức".
              </p>
              <div>
                <button
                  onClick={resetFilters}
                  className="px-4 py-2 bg-brand-primary text-white text-xs font-bold rounded-btn hover:bg-brand-deep transition-colors inline-flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Xóa tất cả bộ lọc
                </button>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
