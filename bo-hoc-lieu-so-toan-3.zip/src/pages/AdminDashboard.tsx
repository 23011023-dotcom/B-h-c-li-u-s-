import React, { useState } from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Users, 
  Layers, 
  FileText, 
  Eye, 
  Search, 
  Filter,
  Check,
  X
} from 'lucide-react';
import { useResources } from '../context/ResourceContext';
import { Resource } from '../types';

export const AdminDashboard: React.FC = () => {
  const { resources, approveResource, rejectResource, setSelectedResourceId, setActiveTab, showToast } = useResources();
  const [rejectReason, setRejectReason] = useState<string>('');
  const [rejectModalId, setRejectModalId] = useState<string | null>(null);

  const pendingList = resources.filter(r => r.status === 'pending');
  const approvedList = resources.filter(r => r.status === 'approved');

  const handleOpenReject = (id: string) => {
    setRejectModalId(id);
    setRejectReason('Cần bổ sung nguồn học liệu rõ ràng hơn hoặc điều chỉnh mức độ bài tập cho chuẩn lớp 3.');
  };

  const handleConfirmReject = () => {
    if (rejectModalId) {
      rejectResource(rejectModalId, rejectReason);
      setRejectModalId(null);
      setRejectReason('');
    }
  };

  return (
    <div className="space-y-6 pb-12 text-left">
      
      {/* Admin Header */}
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-700 uppercase tracking-wider mb-1">
            <ShieldCheck className="w-4 h-4 text-amber-600" />
            <span>Phân hệ Ban Chuyên môn & Quản trị</span>
          </div>
          <h1 className="text-2xl font-extrabold text-brand-text">Bảng điều khiển Kiểm duyệt học liệu</h1>
          <p className="text-xs text-brand-muted mt-0.5">
            Thẩm định chất lượng sư phạm, tính chính xác khoa học và bản quyền trước khi công khai vào kho học liệu chung.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3.5 py-1.5 bg-amber-500 text-white rounded-lg text-xs font-bold shadow-xs">
            {pendingList.length} Học liệu chờ duyệt
          </div>
        </div>
      </div>

      {/* Pending moderation queue */}
      <div className="bg-white rounded-card border border-brand-border overflow-hidden space-y-4 p-5">
        <h2 className="text-sm font-bold text-brand-deep uppercase tracking-wider flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
          Hàng đợi kiểm duyệt học liệu mới
        </h2>

        {pendingList.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-brand-ice border-b border-brand-border text-brand-deep font-bold">
                <tr>
                  <th className="p-3">Học liệu & Tác giả</th>
                  <th className="p-3">Phân loại</th>
                  <th className="p-3">Mục tiêu & Hướng dẫn</th>
                  <th className="p-3 text-right">Hành động thẩm định</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-border">
                {pendingList.map(res => (
                  <tr key={res.id} className="hover:bg-amber-50/40 transition-colors">
                    <td className="p-3 max-w-xs">
                      <div className="font-bold text-brand-text line-clamp-1">{res.title}</div>
                      <div className="text-[11px] text-brand-muted mt-0.5">
                        Người đăng: <strong>{res.authorName}</strong> ({res.authorSchool})
                      </div>
                      <div className="text-[10px] text-brand-sky mt-0.5">{res.fileFormat} • {res.fileSize}</div>
                    </td>
                    <td className="p-3">
                      <span className="font-semibold text-brand-primary block">{res.categoryName}</span>
                      <span className="text-[11px] text-slate-500">{res.cognitiveLevel} • {res.teachingStage}</span>
                    </td>
                    <td className="p-3 max-w-sm">
                      <p className="line-clamp-2 text-slate-700 text-[11px]">{res.objective}</p>
                    </td>
                    <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                      <button
                        onClick={() => {
                          setSelectedResourceId(res.id);
                          setActiveTab('detail');
                        }}
                        className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md inline-flex items-center gap-1 font-semibold"
                        title="Xem chi tiết"
                      >
                        <Eye className="w-3.5 h-3.5" /> Xem
                      </button>
                      <button
                        onClick={() => approveResource(res.id)}
                        className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md inline-flex items-center gap-1 font-bold shadow-xs"
                      >
                        <Check className="w-3.5 h-3.5" /> Phê duyệt
                      </button>
                      <button
                        onClick={() => handleOpenReject(res.id)}
                        className="px-2.5 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-md inline-flex items-center gap-1 font-bold shadow-xs"
                      >
                        <X className="w-3.5 h-3.5" /> Từ chối
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-8 text-center text-xs text-brand-muted">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
            <div className="font-bold text-brand-text">Tuyệt vời! Không còn học liệu nào đang chờ duyệt.</div>
            <p>Tất cả tài nguyên đóng góp đã được Ban chuyên môn xử lý.</p>
          </div>
        )}
      </div>

      {/* Reject Modal */}
      {rejectModalId && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-brand-text flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-5 h-5" />
              Lý do từ chối học liệu
            </h3>
            <p className="text-xs text-brand-muted">
              Vui lòng nêu rõ lý do để giáo viên đóng góp có thể chỉnh sửa và hoàn thiện lại học liệu:
            </p>
            <textarea
              rows={3}
              value={rejectReason}
              onChange={e => setRejectReason(e.target.value)}
              className="w-full text-xs p-3 bg-brand-bg border border-brand-border rounded-lg focus:outline-none focus:border-brand-primary"
            />
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setRejectModalId(null)}
                className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200"
              >
                Hủy
              </button>
              <button
                onClick={handleConfirmReject}
                className="px-4 py-2 text-xs font-bold rounded-lg bg-red-600 text-white hover:bg-red-700"
              >
                Xác nhận từ chối
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
