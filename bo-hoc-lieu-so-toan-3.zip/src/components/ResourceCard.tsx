import React from 'react';
import { 
  Video, 
  FileText, 
  Gamepad2, 
  MousePointerClick, 
  Download, 
  Star, 
  Heart, 
  BookOpen, 
  Clock, 
  ArrowRight 
} from 'lucide-react';
import { Resource, ResourceType } from '../types';
import { useResources } from '../context/ResourceContext';

interface ResourceCardProps {
  resource: Resource;
  onSelect?: (resource: Resource) => void;
}

const TYPE_CONFIG: Record<ResourceType, { label: string; icon: any; bg: string; text: string; badgeBg: string }> = {
  video: { 
    label: 'Video', 
    icon: Video, 
    bg: '#FFF7E8', 
    text: '#B45309', 
    badgeBg: 'bg-amber-100 text-amber-800' 
  },
  worksheet: { 
    label: 'Phiếu bài tập', 
    icon: FileText, 
    bg: '#EAF8F0', 
    text: '#047857', 
    badgeBg: 'bg-emerald-100 text-emerald-800' 
  },
  game: { 
    label: 'Trò chơi', 
    icon: Gamepad2, 
    bg: '#F3EDFF', 
    text: '#6D28D9', 
    badgeBg: 'bg-purple-100 text-purple-800' 
  },
  interactive: { 
    label: 'Tương tác', 
    icon: MousePointerClick, 
    bg: '#E8F8FC', 
    text: '#0E7490', 
    badgeBg: 'bg-cyan-100 text-cyan-800' 
  },
  reference: { 
    label: 'Tài liệu', 
    icon: BookOpen, 
    bg: '#F1F5F9', 
    text: '#475569', 
    badgeBg: 'bg-slate-100 text-slate-800' 
  },
};

const COGNITIVE_LABEL = {
  nhan_biet: 'Nhận biết',
  thong_hieu: 'Thông hiểu',
  van_dung: 'Vận dụng',
};

const STAGE_LABEL = {
  khoi_dong: 'Khởi động',
  kham_pha: 'Khám phá',
  luyen_tap: 'Luyện tập',
  van_dung: 'Vận dụng',
  cung_co: 'Củng cố',
};

export const ResourceCard: React.FC<ResourceCardProps> = ({ resource, onSelect }) => {
  const { favorites, toggleFavorite, downloadResource, setSelectedResourceId, setActiveTab } = useResources();
  const config = TYPE_CONFIG[resource.type] || TYPE_CONFIG.reference;
  const IconComponent = config.icon;
  const isFavorite = favorites.includes(resource.id);

  const handleClick = () => {
    setSelectedResourceId(resource.id);
    setActiveTab('detail');
    if (onSelect) onSelect(resource);
  };

  return (
    <div className="bg-white rounded-card border border-brand-border overflow-hidden transition-all duration-300 hover:shadow-card-hover hover:border-brand-sky flex flex-col group relative">
      
      {/* 16:9 Thumbnail Image */}
      <div className="relative aspect-video w-full overflow-hidden bg-brand-bg cursor-pointer" onClick={handleClick}>
        <img
          src={resource.thumbnailUrl}
          alt={resource.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent opacity-80" />

        {/* Resource Type Badge */}
        <div className="absolute top-3 left-3">
          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold shadow-xs ${config.badgeBg}`}>
            <IconComponent className="w-3.5 h-3.5" />
            {config.label}
          </span>
        </div>

        {/* Favorite Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleFavorite(resource.id);
          }}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-xs flex items-center justify-center text-slate-500 hover:text-red-500 hover:bg-white transition-all shadow-xs"
          title={isFavorite ? "Bỏ yêu thích" : "Lưu vào yêu thích"}
        >
          <Heart className={`w-4 h-4 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
        </button>

        {/* Category & Lesson overlay tag */}
        <div className="absolute bottom-2 left-3 right-3 text-white text-[11px] truncate">
          <span className="font-semibold text-brand-light">{resource.categoryName}</span>
          {resource.lessonName && <span> • {resource.lessonName}</span>}
        </div>
      </div>

      {/* Content Section */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Cognitive & Stage Tags */}
          <div className="flex items-center gap-1.5 mb-2 flex-wrap">
            <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-blue-50 text-brand-primary border border-blue-100">
              {COGNITIVE_LABEL[resource.cognitiveLevel]}
            </span>
            <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-slate-50 text-slate-600 border border-slate-200">
              {STAGE_LABEL[resource.teachingStage]}
            </span>
            <span className="text-[11px] text-brand-muted flex items-center gap-1 ml-auto">
              <Clock className="w-3 h-3" /> {resource.durationMinutes}p
            </span>
          </div>

          {/* Title */}
          <h3 
            onClick={handleClick}
            className="text-[15px] font-bold text-brand-text group-hover:text-brand-primary transition-colors line-clamp-2 cursor-pointer leading-snug mb-1.5"
            title={resource.title}
          >
            {resource.title}
          </h3>

          {/* Description */}
          <p className="text-xs text-brand-muted line-clamp-2 leading-relaxed mb-3">
            {resource.description}
          </p>
        </div>

        {/* Card Footer: Author, Downloads, Rating & CTA */}
        <div className="pt-3 border-t border-brand-border/60 flex items-center justify-between text-xs">
          <div className="flex items-center gap-3 text-brand-muted">
            <span className="flex items-center gap-1">
              <Download className="w-3.5 h-3.5 text-brand-primary" />
              {resource.downloadCount}
            </span>
            <span className="flex items-center gap-1 text-amber-500 font-semibold">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              {resource.ratingAverage > 0 ? resource.ratingAverage : 'Mới'}
            </span>
          </div>

          <button
            onClick={handleClick}
            className="inline-flex items-center gap-1 font-semibold text-brand-primary hover:text-brand-deep hover:underline transition-colors"
          >
            Chi tiết
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
