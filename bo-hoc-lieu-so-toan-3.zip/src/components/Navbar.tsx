import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  PlusCircle, 
  User, 
  ShieldCheck, 
  LogOut, 
  Menu, 
  X, 
  Sparkles,
  LayoutDashboard
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useResources } from '../context/ResourceContext';

export const Navbar: React.FC = () => {
  const { user, role, login, logout, isAdmin } = useAuth();
  const { activeTab, setActiveTab, setFilters } = useResources();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchVal, setSearchVal] = useState('');

  const handleQuickSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setFilters(prev => ({ ...prev, keyword: searchVal }));
    setActiveTab('library');
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-brand-border shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          
          {/* Logo Brand */}
          <div 
            onClick={() => { setActiveTab('home'); }} 
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-brand-deep via-brand-primary to-brand-sky flex items-center justify-center text-white shadow-soft transition-transform group-hover:scale-105">
              <BookOpen className="w-6 h-6 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-brand-deep tracking-wider text-sm bg-brand-light px-2 py-0.5 rounded-md">TOÁN 3</span>
                <span className="text-xs font-semibold text-brand-sky uppercase tracking-wide">Blue Ocean</span>
              </div>
              <h1 className="text-base font-bold text-brand-text tracking-tight flex items-center gap-1">
                BỘ HỌC LIỆU SỐ
              </h1>
            </div>
          </div>

          {/* Nav Links Desktop */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
            {[
              { id: 'home', label: 'Trang chủ' },
              { id: 'library', label: 'Kho học liệu' },
              { id: 'upload', label: 'Chia sẻ học liệu' },
              { id: 'dashboard', label: 'Tủ học liệu của tôi' },
            ].map(tab => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-3 py-2 text-sm font-semibold rounded-lg transition-all relative ${
                    isActive 
                      ? 'text-brand-primary bg-brand-light/70 font-bold' 
                      : 'text-brand-text hover:text-brand-primary hover:bg-brand-ice'
                  }`}
                >
                  {tab.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-2 right-2 h-0.5 bg-brand-primary rounded-full" />
                  )}
                </button>
              );
            })}

            {isAdmin && (
              <button
                onClick={() => setActiveTab('admin')}
                className={`px-3 py-2 text-sm font-semibold rounded-lg flex items-center gap-1.5 transition-all ${
                  activeTab === 'admin'
                    ? 'text-amber-700 bg-amber-50 font-bold'
                    : 'text-amber-600 hover:bg-amber-50'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                Quản trị Admin
              </button>
            )}
          </nav>

          {/* Search bar & User controls */}
          <div className="hidden lg:flex items-center gap-3">
            <form onSubmit={handleQuickSearch} className="relative">
              <input
                type="text"
                placeholder="Tìm bài học, chủ đề..."
                value={searchVal}
                onChange={(e) => setSearchVal(e.target.value)}
                className="w-48 xl:w-60 pl-9 pr-3 py-1.5 text-xs bg-brand-bg border border-brand-border rounded-lg text-brand-text focus:outline-none focus:border-brand-primary focus:w-64 transition-all"
              />
              <Search className="w-4 h-4 text-brand-muted absolute left-2.5 top-2.5" />
            </form>

            {/* Role switch toggle for demonstration */}
            <div className="flex items-center bg-brand-ice border border-brand-border rounded-lg p-0.5 text-xs">
              <button
                onClick={() => login('teacher')}
                className={`px-2 py-1 rounded font-medium transition-all ${
                  role === 'teacher' ? 'bg-brand-primary text-white shadow-xs' : 'text-brand-muted hover:text-brand-text'
                }`}
              >
                Giáo viên
              </button>
              <button
                onClick={() => login('admin')}
                className={`px-2 py-1 rounded font-medium transition-all ${
                  role === 'admin' ? 'bg-amber-600 text-white shadow-xs' : 'text-brand-muted hover:text-brand-text'
                }`}
              >
                Admin
              </button>
            </div>

            {user ? (
              <div className="flex items-center gap-2 pl-2 border-l border-brand-border">
                <img
                  src={user.avatarUrl}
                  alt={user.fullName}
                  className="w-8 h-8 rounded-full object-cover border border-brand-primary/30"
                />
                <div className="text-left hidden xl:block">
                  <div className="text-xs font-bold text-brand-text leading-tight">{user.fullName}</div>
                  <div className="text-[10px] text-brand-muted truncate max-w-[120px]">{user.schoolName || user.role}</div>
                </div>
              </div>
            ) : (
              <button
                onClick={() => login('teacher')}
                className="px-3.5 py-1.5 bg-brand-primary text-white text-xs font-semibold rounded-btn hover:bg-brand-deep transition-all"
              >
                Đăng nhập
              </button>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-brand-text hover:text-brand-primary focus:outline-none"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-brand-border px-4 pt-2 pb-4 space-y-2">
          {[
            { id: 'home', label: 'Trang chủ' },
            { id: 'library', label: 'Kho học liệu' },
            { id: 'upload', label: 'Chia sẻ học liệu' },
            { id: 'dashboard', label: 'Tủ học liệu của tôi' },
            { id: 'admin', label: 'Quản trị viên' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id);
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left px-3 py-2 text-sm font-semibold rounded-lg ${
                activeTab === tab.id ? 'bg-brand-light text-brand-primary' : 'text-brand-text hover:bg-brand-ice'
              }`}
            >
              {tab.label}
            </button>
          ))}
          <div className="pt-2 border-t border-brand-border flex items-center justify-between">
            <div className="text-xs text-brand-muted">Đang đăng nhập với vai trò:</div>
            <div className="flex gap-1">
              <button 
                onClick={() => login('teacher')} 
                className={`text-xs px-2 py-1 rounded ${role === 'teacher' ? 'bg-brand-primary text-white' : 'bg-gray-100'}`}
              >
                Giáo viên
              </button>
              <button 
                onClick={() => login('admin')} 
                className={`text-xs px-2 py-1 rounded ${role === 'admin' ? 'bg-amber-600 text-white' : 'bg-gray-100'}`}
              >
                Admin
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
