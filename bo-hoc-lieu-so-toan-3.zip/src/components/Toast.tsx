import React from 'react';
import { CheckCircle2, AlertTriangle, AlertCircle, Info, X } from 'lucide-react';
import { useResources } from '../context/ResourceContext';

export const ToastContainer: React.FC = () => {
  const { toasts } = useResources();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-5 right-5 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {toasts.map(toast => {
        const isSuccess = toast.type === 'success';
        const isWarning = toast.type === 'warning';
        const isError = toast.type === 'error';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto p-3.5 rounded-xl shadow-lg border flex items-start gap-3 transition-all animate-bounce-in text-xs font-medium ${
              isSuccess
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : isWarning
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : isError
                ? 'bg-red-50 border-red-200 text-red-900'
                : 'bg-blue-50 border-blue-200 text-blue-900'
            }`}
          >
            {isSuccess && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />}
            {isWarning && <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />}
            {isError && <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />}
            {!isSuccess && !isWarning && !isError && <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />}
            <span className="flex-1 leading-snug">{toast.message}</span>
          </div>
        );
      })}
    </div>
  );
};
