import React from 'react';
import { BookOpen, Shield, Heart, Mail, Phone, MapPin, Award } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-deep text-white mt-16 pt-12 pb-8 border-t-4 border-brand-primary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          
          {/* Cột 1: Thông tin dự án */}
          <div>
            <div className="flex items-center gap-2.5 mb-3">
              <div className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center text-white">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <span className="font-extrabold text-sm tracking-wide text-brand-light">TOÁN LỚP 3</span>
                <h3 className="font-bold text-base leading-tight">BỘ HỌC LIỆU SỐ</h3>
              </div>
            </div>
            <p className="text-xs text-blue-100/80 leading-relaxed mb-4">
              Nền tảng học liệu mở chuyên sâu mạch kiến thức Số và Phép tính Toán 3 theo Chương trình GDPT 2018. Kết nối cộng đồng giáo viên tiểu học toàn quốc.
            </p>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-white/10 text-xs text-brand-light">
              <Award className="w-3.5 h-3.5" /> Chuẩn chương trình GDPT 2018
            </div>
          </div>

          {/* Cột 2: Điều hướng nhanh */}
          <div>
            <h4 className="font-bold text-sm text-brand-light uppercase tracking-wider mb-3">Điều hướng học liệu</h4>
            <ul className="space-y-2 text-xs text-blue-100/90">
              <li><a href="#library" className="hover:text-white transition-colors">Video bài giảng hoạt hình</a></li>
              <li><a href="#library" className="hover:text-white transition-colors">Phiếu bài tập phân hóa 3 mức độ</a></li>
              <li><a href="#library" className="hover:text-white transition-colors">Trò chơi học tập Toán học vui</a></li>
              <li><a href="#library" className="hover:text-white transition-colors">Học liệu mô phỏng tương tác</a></li>
              <li><a href="#library" className="hover:text-white transition-colors">Chuyên đề bài toán rút về đơn vị</a></li>
            </ul>
          </div>

          {/* Cột 3: Hướng dẫn & Tiêu chuẩn */}
          <div>
            <h4 className="font-bold text-sm text-brand-light uppercase tracking-wider mb-3">Quy chuẩn chuyên môn</h4>
            <ul className="space-y-2 text-xs text-blue-100/90">
              <li><a href="#guide" className="hover:text-white transition-colors">Quy trình kiểm duyệt 2 vòng</a></li>
              <li><a href="#guide" className="hover:text-white transition-colors">Khung nhận thức: Nhận biết - Vận dụng</a></li>
              <li><a href="#guide" className="hover:text-white transition-colors">5 giai đoạn tiến trình dạy học</a></li>
              <li><a href="#guide" className="hover:text-white transition-colors">Hướng dẫn đóng góp học liệu</a></li>
              <li><a href="#guide" className="hover:text-white transition-colors">Chính sách bản quyền CC BY-NC 4.0</a></li>
            </ul>
          </div>

          {/* Cột 4: Liên hệ & Góp ý */}
          <div>
            <h4 className="font-bold text-sm text-brand-light uppercase tracking-wider mb-3">Ban quản trị & Liên hệ</h4>
            <div className="space-y-2.5 text-xs text-blue-100/90">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-brand-sky shrink-0 mt-0.5" />
                <span>Viện Khoa học Giáo dục / Khoa GD Tiểu học</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-brand-sky shrink-0" />
                <span>chuyenmon.toan3@eduplatform.vn</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-brand-sky shrink-0" />
                <span>Hotline hỗ trợ: 1900 6833</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bản quyền */}
        <div className="pt-6 border-t border-white/10 text-center text-xs text-blue-100/60 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            © 2026 BỘ HỌC LIỆU SỐ TOÁN 3. Blue Ocean Theme – Thiết kế dành cho Giáo viên Việt Nam.
          </div>
          <div className="flex items-center gap-1">
            <span>Xây dựng với tâm huyết cho</span>
            <Heart className="w-3.5 h-3.5 text-red-400 fill-red-400 inline" />
            <span>Giáo dục Tiểu học</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
