import React from 'react';
import { SlidersHorizontal, RotateCcw, Check } from 'lucide-react';
import { useResources } from '../context/ResourceContext';
import { ResourceType, CognitiveLevel, TeachingStage } from '../types';

export const ResourceFilter: React.FC = () => {
  const { filters, setFilters, resetFilters, categories } = useResources();

  const handleTypeToggle = (type: ResourceType) => {
    setFilters(prev => ({
      ...prev,
      types: prev.types.includes(type)
        ? prev.types.filter(t => t !== type)
        : [...prev.types, type]
    }));
  };

  const handleCategoryToggle = (catId: string) => {
    setFilters(prev => ({
      ...prev,
      categories: prev.categories.includes(catId)
        ? prev.categories.filter(c => c !== catId)
        : [...prev.categories, catId]
    }));
  };

  const handleCognitiveToggle = (level: CognitiveLevel) => {
    setFilters(prev => ({
      ...prev,
      cognitiveLevels: prev.cognitiveLevels.includes(level)
        ? prev.cognitiveLevels.filter(l => l !== level)
        : [...prev.cognitiveLevels, level]
    }));
  };

  const handleStageToggle = (stage: TeachingStage) => {
    setFilters(prev => ({
      ...prev,
      teachingStages: prev.teachingStages.includes(stage)
        ? prev.teachingStages.filter(s => s !== stage)
        : [...prev.teachingStages, stage]
    }));
  };

  return (
    <div className="bg-white rounded-card border border-brand-border p-5 space-y-6">
      
      {/* Header filter */}
      <div className="flex items-center justify-between pb-3 border-b border-brand-border">
        <div className="flex items-center gap-2 text-brand-deep font-bold text-sm">
          <SlidersHorizontal className="w-4 h-4 text-brand-primary" />
          <span>Bộ lọc học liệu</span>
        </div>
        <button
          onClick={resetFilters}
          className="text-xs text-brand-primary hover:text-brand-deep flex items-center gap-1 font-medium transition-colors"
        >
          <RotateCcw className="w-3 h-3" />
          Xóa lọc
        </button>
      </div>

      {/* 1. Loại học liệu */}
      <div>
        <h4 className="text-xs font-bold text-brand-text uppercase tracking-wider mb-2.5">Loại học liệu</h4>
        <div className="space-y-1.5 text-xs">
          {[
            { id: 'video', label: 'Video bài giảng' },
            { id: 'worksheet', label: 'Phiếu bài tập' },
            { id: 'game', label: 'Trò chơi học tập' },
            { id: 'interactive', label: 'Bài tập tương tác' },
          ].map(item => {
            const isChecked = filters.types.includes(item.id as ResourceType);
            return (
              <label 
                key={item.id} 
                className="flex items-center gap-2.5 p-1.5 rounded hover:bg-brand-ice cursor-pointer transition-colors"
              >
                <input
                  type="checkbox"
                  checked={isChecked}
                  onChange={() => handleTypeToggle(item.id as ResourceType)}
                  className="rounded text-brand-primary focus:ring-brand-primary h-4 w-4 border-brand-border"
                />
                <span className={isChecked ? "font-semibold text-brand-primary" : "text-brand-text"}>
                  {item.label}
                </span>
              </label>
            );
          })}
        </div>
      </div>

      {/* 2. Chủ đề kiến thức Toán 3 */}
      <div>
        <h4 className="text-xs font-bold text-brand-text uppercase tracking-wider mb-2.5">Chủ đề kiến thức</h4>
        <div className="space-y-1.5 text-xs max-h-48 overflow-y-auto pr-1">
          {categories.map(cat => {
            const isChecked = filters.categories.includes(cat.id);
            return (
              <label 
                key={cat.id} 
                className="flex items-start gap-2.5 p-1.5 rounded hover:bg-brand-ice cursor-pointer transition-colors"
              >
                <input
                  type="checkbox"
                  checked={isChecked}
                  onChange={() => handleCategoryToggle(cat.id)}
                  className="rounded text-brand-primary focus:ring-brand-primary h-4 w-4 border-brand-border mt-0.5"
                />
                <span className={`leading-snug ${isChecked ? "font-semibold text-brand-primary" : "text-brand-text"}`}>
                  {cat.name}
                </span>
              </label>
            );
          })}
        </div>
      </div>

      {/* 3. Mức độ nhận thức */}
      <div>
        <h4 className="text-xs font-bold text-brand-text uppercase tracking-wider mb-2.5">Mức độ nhận thức</h4>
        <div className="space-y-1.5 text-xs">
          {[
            { id: 'nhan_biet', label: 'Nhận biết' },
            { id: 'thong_hieu', label: 'Thông hiểu' },
            { id: 'van_dung', label: 'Vận dụng' },
          ].map(item => {
            const isChecked = filters.cognitiveLevels.includes(item.id as CognitiveLevel);
            return (
              <label 
                key={item.id} 
                className="flex items-center gap-2.5 p-1.5 rounded hover:bg-brand-ice cursor-pointer transition-colors"
              >
                <input
                  type="checkbox"
                  checked={isChecked}
                  onChange={() => handleCognitiveToggle(item.id as CognitiveLevel)}
                  className="rounded text-brand-primary focus:ring-brand-primary h-4 w-4 border-brand-border"
                />
                <span className={isChecked ? "font-semibold text-brand-primary" : "text-brand-text"}>
                  {item.label}
                </span>
              </label>
            );
          })}
        </div>
      </div>

      {/* 4. Giai đoạn tiến trình dạy học */}
      <div>
        <h4 className="text-xs font-bold text-brand-text uppercase tracking-wider mb-2.5">Giai đoạn dạy học</h4>
        <div className="space-y-1.5 text-xs">
          {[
            { id: 'khoi_dong', label: '1. Khởi động' },
            { id: 'kham_pha', label: '2. Khám phá' },
            { id: 'luyen_tap', label: '3. Luyện tập' },
            { id: 'van_dung', label: '4. Vận dụng' },
            { id: 'cung_co', label: '5. Củng cố' },
          ].map(item => {
            const isChecked = filters.teachingStages.includes(item.id as TeachingStage);
            return (
              <label 
                key={item.id} 
                className="flex items-center gap-2.5 p-1.5 rounded hover:bg-brand-ice cursor-pointer transition-colors"
              >
                <input
                  type="checkbox"
                  checked={isChecked}
                  onChange={() => handleStageToggle(item.id as TeachingStage)}
                  className="rounded text-brand-primary focus:ring-brand-primary h-4 w-4 border-brand-border"
                />
                <span className={isChecked ? "font-semibold text-brand-primary" : "text-brand-text"}>
                  {item.label}
                </span>
              </label>
            );
          })}
        </div>
      </div>

    </div>
  );
};
