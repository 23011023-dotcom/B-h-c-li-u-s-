export type ResourceType = 'video' | 'worksheet' | 'game' | 'interactive' | 'reference';

export type CognitiveLevel = 'nhan_biet' | 'thong_hieu' | 'van_dung';

export type TeachingStage = 'khoi_dong' | 'kham_pha' | 'luyen_tap' | 'van_dung' | 'cung_co';

export type ResourceStatus = 'draft' | 'pending' | 'approved' | 'rejected';

export type UserRole = 'teacher' | 'admin' | 'student';

export interface UserProfile {
  id: string;
  email: string;
  fullName: string;
  role: UserRole;
  avatarUrl?: string;
  schoolName?: string;
  created_at: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  orderIndex: number;
}

export interface Lesson {
  id: string;
  categoryId: string;
  name: string;
  code: string;
}

export interface Comment {
  id: string;
  resourceId: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  userAvatar?: string;
  content: string;
  createdAt: string;
}

export interface Resource {
  id: string;
  title: string;
  slug: string;
  description: string;
  type: ResourceType;
  categoryId: string;
  categoryName: string;
  lessonId?: string;
  lessonName?: string;
  cognitiveLevel: CognitiveLevel;
  teachingStage: TeachingStage;
  thumbnailUrl: string;
  previewUrl?: string;
  downloadUrl?: string;
  embedCode?: string;
  interactiveType?: 'canvas_game' | 'simulation' | 'pdf' | 'video';
  fileSize?: string;
  fileFormat?: string;
  objective: string;
  teachingGuide: string;
  durationMinutes: number;
  authorId: string;
  authorName: string;
  authorSchool?: string;
  copyrightInfo: string;
  status: ResourceStatus;
  rejectionReason?: string;
  ratingAverage: number;
  ratingCount: number;
  downloadCount: number;
  viewCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface FilterState {
  keyword: string;
  types: ResourceType[];
  categories: string[];
  cognitiveLevels: CognitiveLevel[];
  teachingStages: TeachingStage[];
  sortBy: 'newest' | 'oldest' | 'rating' | 'downloads';
  page: number;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'warning' | 'error' | 'info';
  message: string;
}
