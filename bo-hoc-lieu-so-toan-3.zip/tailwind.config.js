/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          primary: '#1479D1',
          deep: '#0756A3',
          sky: '#38A5E8',
          light: '#DDF1FF',
          ice: '#F0F8FF',
          bg: '#F5F8FC',
          border: '#E2EAF3',
          text: '#1E293B',
          muted: '#64748B',
        },
        resource: {
          video: '#F59E0B',
          worksheet: '#16A36A',
          game: '#8B5CF6',
          interactive: '#0891B2',
          danger: '#DC5252',
        }
      },
      fontFamily: {
        sans: ['"Be Vietnam Pro"', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        'card': '14px',
        'btn': '8px',
      },
      boxShadow: {
        'soft': '0 4px 20px -2px rgba(20, 121, 209, 0.08), 0 2px 6px -1px rgba(0, 0, 0, 0.04)',
        'card-hover': '0 12px 28px -4px rgba(20, 121, 209, 0.16), 0 4px 12px -2px rgba(0, 0, 0, 0.05)',
      }
    },
  },
  plugins: [],
}
