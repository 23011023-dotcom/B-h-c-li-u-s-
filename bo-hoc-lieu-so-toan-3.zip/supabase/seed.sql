-- SEED DATA FOR TOAN LOP 3 PLATFORM

-- 1. Insert Categories
INSERT INTO public.categories (id, name, slug, description, order_index) VALUES
('c1000000-0000-0000-0000-000000000001', 'Các số trong phạm vi 100 000', 'cac-so-trong-pham-vi-100-000', 'Đọc, viết, so sánh và xác định cấu tạo thập phân của các số có 4, 5 chữ số.', 1),
('c1000000-0000-0000-0000-000000000002', 'Phép cộng và phép trừ', 'phep-cong-va-phep-tru', 'Kỹ năng tính nhẩm và đặt tính rồi tính phép cộng, trừ có nhớ trong phạm vi 100 000.', 2),
('c1000000-0000-0000-0000-000000000003', 'Bảng nhân và bảng chia', 'bang-nhan-va-bang-chia', 'Thuộc lòng và vận dụng thành thạo bảng nhân, bảng chia từ 2 đến 9.', 3),
('c1000000-0000-0000-0000-000000000004', 'Phép nhân và phép chia ngoài bảng', 'phep-nhan-va-phep-chia-ngoai-bang', 'Nhân, chia số có nhiều chữ số với số có một chữ số, phép chia hết và chia có dư.', 4),
('c1000000-0000-0000-0000-000000000005', 'Biểu thức số & Giá trị biểu thức', 'bieu-thuc-so', 'Quy tắc tính giá trị của biểu thức có hoặc không có dấu ngoặc.', 5),
('c1000000-0000-0000-0000-000000000006', 'Tìm thành phần chưa biết', 'tim-thanh-phan-chua-biet', 'Tìm số hạng, số bị trừ, thừa số, số bị chia chưa biết.', 6),
('c1000000-0000-0000-0000-000000000007', 'Giải toán có lời văn', 'giai-toan-co-loi-van', 'Bài toán giải bằng 2 bước tính, bài toán liên quan đến rút về đơn vị.', 7)
ON CONFLICT (id) DO NOTHING;
