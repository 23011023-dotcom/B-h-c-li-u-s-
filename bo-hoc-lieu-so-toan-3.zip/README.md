# BỘ HỌC LIỆU SỐ – TOÁN LỚP 3 (Blue Ocean Theme)
> **Educational Resource Platform** – Nền tảng học liệu mở chuyên sâu mạch kiến thức *Số và Phép tính Toán lớp 3* theo Chương trình GDPT 2018.

---

## 1. Giới thiệu tổng quan
Dự án được thiết kế theo phong cách **Modern Educational – Clean – Friendly**, lấy tone màu **Ocean Blue** làm chủ đạo, hướng tới đối tượng chính là **Giáo viên tiểu học và Sinh viên ngành Giáo dục Tiểu học**.

Hệ thống cung cấp trải nghiệm số đồng bộ:
- **Trang chủ (Home):** Nhận diện thương hiệu chuẩn mực, số liệu thống kê thời gian thực, 4 phân loại học liệu lớn, tài nguyên nổi bật và tài nguyên mới cập nhật.
- **Kho học liệu (Resource Library):** Hệ thống lọc 5 chiều độc lập & kết hợp (Định dạng, Mạch kiến thức Toán 3, Mức độ nhận thức, Giai đoạn dạy học, Sắp xếp).
- **Trang chi tiết học liệu (Detail):** Khung xem trước trực tiếp (Video bài giảng, Phiếu in PDF, Trò chơi HTML5 tương tác), thông tin sư phạm chuẩn mực, thanh công cụ tải về & lưu yêu thích, bình luận đánh giá sao.
- **Trang đăng tải học liệu (Upload):** Biểu mẫu 5 nhóm sư phạm chuyên nghiệp (A: Thông tin, B: Phân loại, C: Tệp/Drive, D: Mục tiêu sư phạm, E: Cam kết bản quyền).
- **Tủ học liệu cá nhân (Dashboard):** Quản lý học liệu đã đăng, theo dõi trạng thái duyệt, danh sách yêu thích và lịch sử tải.
- **Phân hệ Quản trị viên (Admin Moderation):** Thẩm định học liệu chờ duyệt, phê duyệt công khai hoặc từ chối kèm lý do phản hồi cho giáo viên.

---

## 2. Bảng màu nhận diện & Quy chuẩn thiết kế

| Thành phần | Mã màu | Ý nghĩa sử dụng |
| :--- | :--- | :--- |
| **Primary Blue** | `#1479D1` | Nút hành động chính, nhận diện thương hiệu, liên kết |
| **Deep Blue** | `#0756A3` | Header logo, Footer, thanh tiêu đề lớn |
| **Sky Blue** | `#38A5E8` | Màu bổ trợ, thẻ số, điểm nhấn |
| **Light Blue** | `#DDF1FF` | Nền gradient banner, nút phụ |
| **Ice Blue** | `#F0F8FF` | Nền thanh công cụ, bảng điều khiển |
| **Background** | `#F5F8FC` | Nền trang tổng thể (sáng, thoáng mắt) |
| **Main Text** | `#1E293B` | Màu chữ chính, tiêu đề |
| **Video** | `#F59E0B` | Nhãn phân loại Video bài giảng |
| **Phiếu bài tập** | `#16A36A` | Nhãn phân loại Phiếu bài tập in |
| **Trò chơi** | `#8B5CF6` | Nhãn phân loại Trò chơi tương tác |
| **Bài tập tương tác** | `#0891B2` | Nhãn phân loại Mô phỏng toán học |

- **Font chữ chính:** `Be Vietnam Pro` (400, 500, 600, 700, 800).
- **Bộ icon chuẩn:** Lucide Icons nét bo tròn đồng nhất (`stroke-width: 2`).

---

## 3. Cấu trúc thư mục mã nguồn

```
bo-hoc-lieu-so-toan-3/
├── index.html                  # HTML template chính với font Be Vietnam Pro
├── package.json                # Cấu hình phụ thuộc React, Vite, Tailwind, Lucide, Supabase
├── vite.config.ts              # Cấu hình Vite & Alias @/
├── tsconfig.json               # Cấu hình TypeScript nghiêm ngặt
├── tailwind.config.js          # Hệ màu Ocean Blue Theme & Bo góc chuẩn
├── postcss.config.js           # PostCSS & Tailwind Autoprefixer
├── .env.example                # Biến môi trường mẫu cho Supabase
├── supabase/
│   ├── schema.sql              # CSDL PostgreSQL với đầy đủ Row-Level Security (RLS)
│   └── seed.sql                # Dữ liệu hạt giống chuẩn môn Toán 3
└── src/
    ├── main.tsx                # Điểm khởi động React 18
    ├── App.tsx                 # Điều phối trang và quản lý layout
    ├── index.css               # Global CSS & Tailwind Directives
    ├── types/
    │   └── index.ts            # Khai báo TypeScript types (Resource, Profile, Filters...)
    ├── services/
    │   └── supabase.ts         # Khởi tạo Supabase client & fallback an toàn
    ├── context/
    │   ├── AuthContext.tsx     # Phân quyền Người dùng (Teacher / Admin)
    │   └── ResourceContext.tsx # Quản lý học liệu, bộ lọc, yêu thích, kiểm duyệt
    ├── components/
    │   ├── Navbar.tsx          # Thanh điều hướng sticky với thanh tìm kiếm nhanh
    │   ├── Footer.tsx          # Chân trang 4 cột chuyên nghiệp
    │   ├── ResourceCard.tsx    # Thẻ học liệu chuẩn tỉ lệ 16:9, màu nhãn theo loại
    │   ├── ResourceFilter.tsx  # Bộ lọc 5 chiều độc lập
    │   └── Toast.tsx           # Hệ thống thông báo toast phản hồi người dùng
    ├── pages/
    │   ├── HomePage.tsx        # Trang chủ đầy đủ banner, thống kê, khám phá 4 loại
    │   ├── LibraryPage.tsx     # Kho học liệu số với bộ lọc và tìm kiếm
    │   ├── DetailPage.tsx      # Chi tiết học liệu, xem trước tương tác, đánh giá, bình luận
    │   ├── UploadPage.tsx      # Đăng tải học liệu chia 5 nhóm chuẩn sư phạm
    │   ├── UserDashboard.tsx   # Dashboard cá nhân của giáo viên
    │   └── AdminDashboard.tsx  # Bảng điều khiển kiểm duyệt của Ban chuyên môn
    └── data/
        └── initialData.ts      # Dữ liệu chuẩn hóa 7 mạch kiến thức Toán lớp 3
```

---

## 4. Hướng dẫn cài đặt & Khởi chạy

### Bước 1: Cài đặt thư viện phụ thuộc
Yêu cầu Node.js phiên bản >= 18.0:
```bash
npm install
```

### Bước 2: Thiết lập biến môi trường Supabase (Tùy chọn)
Tạo tệp `.env` từ `.env.example`:
```bash
cp .env.example .env
```
Điền URL và Anon Key dự án Supabase của bạn:
```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```
*(Nếu chưa cấu hình Supabase, hệ thống tự động kích hoạt Mock Service an toàn chạy 100% chức năng offline).*

### Bước 3: Khởi chạy môi trường phát triển (Dev Server)
```bash
npm run dev
```
Ứng dụng sẽ chạy tại địa chỉ: `http://localhost:3000/`.

### Bước 4: Đóng gói sản phẩm (Production Build)
```bash
npm run build
```
Mã nguồn tối ưu sẽ được biên dịch vào thư mục `dist/`, sẵn sàng đưa lên Vercel, Netlify hoặc GitHub Pages.

---

## 5. Thiết lập Cơ sở dữ liệu Supabase

1. Đăng nhập vào [Supabase Console](https://supabase.com).
2. Vào mục **SQL Editor**.
3. Sao chép toàn bộ nội dung từ tệp `supabase/schema.sql` và nhấn **Run**.
4. Toàn bộ 10 bảng dữ liệu (`profiles`, `categories`, `lessons`, `resources`, `favorites`, `comments`, `ratings`, `downloads`, `notifications`, `reports`) cùng các chính sách bảo mật **Row Level Security (RLS)** sẽ được tự động thiết lập.

---

## 6. Bản quyền & Phân phối
- Bộ học liệu số được phát triển nhằm mục tiêu hỗ trợ cộng đồng giáo viên và sinh viên tiểu học Việt Nam.
- Được cấp phép theo Giấy phép **MIT License & Creative Commons CC BY-NC 4.0**.
